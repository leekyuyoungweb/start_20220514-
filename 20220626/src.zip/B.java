
public class B implements DataService{

	public int getData() {
		return 100;
	}
}
