package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginService;
import model.MemberVO;

public class LoginController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		RequestDispatcher rd = req.getRequestDispatcher("/member/loginMember.jsp");
		rd.forward(req, resp);
	}

	/**
	 * id, psw를 view에서 전달받아서 DB를 조회해서 같으면 또는 틀리면
	 */
	@Override	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		resp.setContentType("text/html; charset=utf-8");
		String id =  req.getParameter("id");
		String psw = req.getParameter("password");
		// 모델을 호출
		LoginService loginsv = new LoginService();
		MemberVO vo =  loginsv.getMember(id,psw);
		RequestDispatcher rd = null;
		if (vo != null){
			HttpSession session =  req.getSession();
			session.setAttribute("sessionId", id);			 
			rd = req.getRequestDispatcher("/member/resultMember.jsp?msg=2");
		}
		else
			rd = req.getRequestDispatcher("/member/loginMember.jsp?error=1");
		rd.forward(req, resp);
		
	}

}
