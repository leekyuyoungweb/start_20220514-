import java.util.ArrayList;
import java.util.List;

public class Util {

	private int values;
	private static Util instance; // 자기자신 타입의 객체를 맴버로 가진다.
	private List<Integer> myList=new ArrayList<>();
	private Util() {
		myList.add(1);
		myList.add(2);
		myList.add(3);
		myList.add(4);
		myList.add(5);
	}
	public static Util getInstance() {
		if( instance == null)
			instance = new Util();
		return instance;	
	}
	public void addData(int a) {
		myList.add(a);
	}
	public void show() {
		System.out.println(myList);
	}
	
}
