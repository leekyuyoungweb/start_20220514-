package spring.lecture.basic;

import java.util.Map;

public interface MemberService {
	public boolean create(Map<String, Object> map);
}
