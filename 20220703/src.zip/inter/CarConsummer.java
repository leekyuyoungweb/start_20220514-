package inter;

import intertest.Car;

public interface CarConsummer {
	void apply(Car car);
}
