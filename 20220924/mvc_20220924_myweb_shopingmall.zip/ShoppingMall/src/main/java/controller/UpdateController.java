package controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.MemberVO;
import model.UpdateService;

public class UpdateController extends HttpServlet {
	
	private UpdateService service = new UpdateService(); 
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("/member/updateMember.jsp");
		rd.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String year = request.getParameter("birthyy");
		String month = request.getParameterValues("birthmm")[0];
		String day = request.getParameter("birthdd");
		String birth = year + "/" + month + "/" + day;
		String mail1 = request.getParameter("mail1");
		String mail2 = request.getParameterValues("mail2")[0];
		String mail = mail1 + "@" + mail2;
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		DateFormat  df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal =  Calendar.getInstance();
		String timestamp =  df.format(cal.getTime());
		MemberVO vo = new MemberVO(address, birth, gender, id, mail, name, password, phone, day);
		// 회원업데이를 처리하는 모델을 호출
		RequestDispatcher rd = null;
		if(service.updateMember(vo))
		{
			rd = request.getRequestDispatcher("/member/resultMember.jsp?msg=0");
			rd.forward(request, resp);
		}
	}

}
