package inter;
// 면적을 구하는 메서드를 가지고 있다.
public interface Plane2D {
	long getArea(); // 면적구하기
}
