
public class UtilMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Util u = Util.getInstance();
		u.addData(10);
		u.addData(20);
		u.show();
		
		
		Util uu = Util.getInstance();		
		uu.addData(100);
		uu.show();
	}

}
