package com.shopping.mall.controller;

import org.json.simple.JSONArray;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class AjaxController {
	@ResponseBody
    @RequestMapping("/ajaxTest")
    public JSONArray ajaxTest(String data){
        //data : JSON.stringify(testArr)
        //[{num:1, score:90}, {num:2, score:80}, {num:3, score:70}]		
        JSONArray jsonArr = new JSONArray();
        ObjectMapper mapper = new ObjectMapper();        
        
        try { 	
            //JSONArray 타입으로 파싱
            jsonArr = mapper.readValue(data, JSONArray.class);
            System.out.println("controller : " + jsonArr);        	
        	
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONArray test = new JSONArray();
        test.add(0, 100);
        return test;
    }
}
