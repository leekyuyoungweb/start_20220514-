package sample;

public class Student extends Human{
	
}
