package collection;

public class Dog implements Animal{

	private A a;
	
	@Override
	public void bark() {
		// TODO Auto-generated method stub		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
