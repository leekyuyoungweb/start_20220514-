package generic;

public class CustomArray<T> {
	

}
