/**
 * 
 */
 
 function check(regExp, e, msg){
	if(e.value.length != 0 && regExp.test(e.value)){
		return true;
	}
	alert(msg);
	e.select();
	e.focus();
	return false;
}
 
 function checkAddProduct(frm){
	var productId =  document.getElementById("productId"); // 상품아이디
	var pname =  document.getElementById("pname");		// 상품명
	var price =  document.getElementById("price");	// 가격
	var unitStock =  document.getElementById("unitStock"); // 재고수
	
	// 아이디 체크  P0001~P00000000001  5 ~ 12
	if( !check(/^P[0-9]{4,11}$/,productId,"P로시작하고 숫자로 되어 있는 5~12자리 코드를 입력") )
		return false;
	else if(!check(/^[a-zA-Z가-힣]*$/,pname,'한글이나 영문으로 작성해 주세요') )
		return false
	else if( !check(/^[1-9][0-9]{3,}$/,price,'숫자로 작성해 주세요') )
		return false
	else if( !check(/^[0-9]*$/,unitStock,'숫자로 작성해 주세요') )
		return false	
	else
		frm.submit();
}