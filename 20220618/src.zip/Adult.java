
public class Adult extends Human {

	@Override
	public long getPrice() {		
		return (long) (12000*0.9);
	}

}
