package trycatch;

public class CheckAge extends Exception {
	public CheckAge(String message) {
		super(message);		
	}		
}
