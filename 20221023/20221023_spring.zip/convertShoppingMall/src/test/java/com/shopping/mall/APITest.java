package com.shopping.mall;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Test;

public class APITest {

//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}

	
	public void apiTest() throws Exception {
		StringBuilder urlBuilder = new StringBuilder("http://openapi.seoul.go.kr:8088"); /* URL */
		urlBuilder.append("/"
				+ URLEncoder.encode("6257556a707069613130386f61594361", "UTF-8")); /* 인증키 (sample사용시에는 호출시 제한됩니다.) */
		urlBuilder.append("/" + URLEncoder.encode("json", "UTF-8")); /* 요청파일타입 (xml,xmlf,xls,json) */
		urlBuilder.append("/" + URLEncoder.encode("LOCALDATA_031101", "UTF-8")); /* 서비스명 (대소문자 구분 필수입니다.) */
		urlBuilder.append("/" + URLEncoder.encode("1", "UTF-8")); /* 요청시작위치 (sample인증키 사용시 5이내 숫자) */
		urlBuilder.append("/" + URLEncoder.encode("5", "UTF-8")); /* 요청종료위치(sample인증키 사용시 5이상 숫자 선택 안 됨) */
		// 상위 5개는 필수적으로 순서바꾸지 않고 호출해야 합니다.

		// 서비스별 추가 요청 인자이며 자세한 내용은 각 서비스별 '요청인자'부분에 자세히 나와 있습니다.
//		urlBuilder.append("/" + URLEncoder.encode("20220301","UTF-8")); /* 서비스별 추가 요청인자들*/

		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/xml");
		System.out.println("Response code: " + conn.getResponseCode()); /* 연결 자체에 대한 확인이 필요하므로 추가합니다. */
		BufferedReader rd;

		// 서비스코드가 정상이면 200~300사이의 숫자가 나옵니다.
		if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = rd.readLine()) != null) {
			sb.append(line+"\n");
//			System.out.println(line);
		}
		rd.close();
		conn.disconnect();
		System.out.println(sb.toString());
	}
	
	@Test
	public void getWebCrawling2() {
		// #postSearchFrm > section > div.article-list-slide > ul
		int pagenum = 0;
		String url = "https://korean.visitseoul.net/restaurants?curPage=1";
		try {
			Document doc =   Jsoup.connect(url).get();
			Elements elem = doc.select("#postSearchFrm > section > div.article-list-slide > ul > li");
			for(Element e : elem) {
				String subPath = "https://korean.visitseoul.net" + e.select("a").attr("href");
				System.out.println(e.select("span.title").text());
				System.out.println(e.select("span.small-text.text-dot-d").text());				
				System.out.println(subPath);
				getLink(subPath);
			}		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void getLink(String url) throws Exception {
		Document doc =   Jsoup.connect(url).get();
		Elements elem = doc.select("#container > div.detial-cont-element.active > div > dl");
		for (Element e : elem) {
			System.out.println(e.select("dt").text() + " : " + e.select("dd").text());			
		}
	}
	
	
	public void getWebCrawling() {		
		for (int pagenum = 0; pagenum < 130; pagenum++) {
			String url = "https://korean.visitseoul.net/restaurants?curPage="+pagenum;		
			try {
				Document doc =   Jsoup.connect(url).get();
				Elements elem = doc.select("div > span.small-text.text-dot-d");
				for(Element e : elem) {
					System.out.println(e.text());
				}		
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}			
	}
	

}
