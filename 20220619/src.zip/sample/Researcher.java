package sample;

public class Researcher extends Human{	
	public void research() {}
}
