package spring.lecture.basic;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MemberController {

	@RequestMapping(value = "/member", method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("member/member");
	}
}
