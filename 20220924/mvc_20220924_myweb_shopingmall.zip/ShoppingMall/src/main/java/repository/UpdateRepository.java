package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

import db.DbConn;
import model.MemberVO;

public class UpdateRepository {
	private Connection conn=null;
	public UpdateRepository() {
		try {
			conn = DbConn.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public boolean updateMember(MemberVO vo) {
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			String sql = "UPDATE MEMBER SET passwd=?, NAME=?, GENDER=?"
					+ ", BIRTH=?, MAIL=?, PHONE=?, ADDRESS=? WHERE ID=?";			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getPasswd());
			pstmt.setString(2, vo.getName());
			pstmt.setString(3, vo.getGender());
			pstmt.setString(4, vo.getBirth());
			pstmt.setString(5, vo.getMail());
			pstmt.setString(6, vo.getPhone());
			pstmt.setString(7, vo.getAddress());
			pstmt.setString(8, vo.getId());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			
		}
		return result == 1;
	}

}
