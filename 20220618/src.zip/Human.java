
public class Human {
	int age;
	public long getPrice() {
		return 0L;
	}
}
