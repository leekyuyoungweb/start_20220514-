package com.shopping.mall.model;

import java.util.List;
import java.util.Map;

import com.shopping.mall.vo.BoardVO;

public interface BoardService {

	List<BoardVO> list(Map<String, Object> map);

}
