package db;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DbConn {
	private DbConn() {}
	public static Connection getConnection() throws Exception {

		InputStream is = DbConn.class.getResourceAsStream("db.properties");
		Properties pro = new Properties();		
		pro.load(is);		
		String url = pro.getProperty("url");//"jdbc:mysql://localhost:3306/webmarketdb";
		String user = pro.getProperty("user");// "admin";
		String psw = pro.getProperty("psw");// "admin1234";	
		Class.forName(pro.getProperty("dirivername"));
		return DriverManager.getConnection(url,user,psw);		
	}
}
