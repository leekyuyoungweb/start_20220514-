package sample;


public class A {
	private int private_value_a;
	protected int protected_value_a;
	public int public_value_a;
	int value_a;
}
