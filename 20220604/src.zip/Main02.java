
public class Main02 {

	public static void main(String[] args) {
		// 1���� �迭 : ��Ұ� �⺻����
//		int a = 10, b=20, c=30;
//		int[] ary = {a,b,c};
		
		
		int[] a = {1,2,3}, b= {4,5,6}, c= {7,8,9};
		int[][] ary = {a,b,c},ary2 = {a,b,c},ary3 = {a,b,c};
		
		int[][][] ary3th ={ary,ary2,ary3};

	}

}
