package collection;

public class A {

}
