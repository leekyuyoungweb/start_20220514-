
public class C implements DataService{
	public int getData() {
		return 500;
	}
}
