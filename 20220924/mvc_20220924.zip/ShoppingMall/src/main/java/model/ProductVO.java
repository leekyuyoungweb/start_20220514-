package model;

public class ProductVO {
	private String category;
	private String filename;
	private String manufacturer;
	private String pcondition;
	private String pdesc;
	private String pname;
	private String price;
	private String productId;
	private String unitStock;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getPcondition() {
		return pcondition;
	}
	public void setPcondition(String pcondition) {
		this.pcondition = pcondition;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getUnitStock() {
		return unitStock;
	}
	public void setUnitStock(String unitStock) {
		this.unitStock = unitStock;
	}
	public ProductVO(String category, String filename, String manufacturer, String pcondition, String pdesc,
			String pname, String price, String productId, String unitStock) {
		super();
		this.category = category;
		this.filename = filename;
		this.manufacturer = manufacturer;
		this.pcondition = pcondition;
		this.pdesc = pdesc;
		this.pname = pname;
		this.price = price;
		this.productId = productId;
		this.unitStock = unitStock;
	}
	public ProductVO() {}
}
