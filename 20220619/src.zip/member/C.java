package member;

import sample.A;

public class C {

	public static void main(String[] args) {
		A a = new A();
		a.public_value_a=0;

	}

}
