package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.LoginService;
import model.MemberVO;

public class LoginController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		RequestDispatcher rd = req.getRequestDispatcher("/member/loginMember.jsp");
		rd.forward(req, resp);
	}

	/**
	 * id, psw를 view에서 전달받아서 DB를 조회해서 같으면 또는 틀리면
	 */
	@Override	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		resp.setContentType("text/html; charset=utf-8");
		String id =  req.getParameter("id");
		String psw = req.getParameter("passwd");
		// 모델을 호출
		LoginService loginsv = new LoginService();
		MemberVO vo =  loginsv.getMember(id,psw);
		RequestDispatcher rd = null;
		if (vo.getId().equals(id) && vo.getPasswd().equals(psw))			
			rd = req.getRequestDispatcher("login_success.jsp");
		else
			rd = req.getRequestDispatcher("login_faile.jsp");
		rd.forward(req, resp);
		
	}

}
