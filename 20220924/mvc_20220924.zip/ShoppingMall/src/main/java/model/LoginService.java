package model;

public class LoginService {

	public MemberVO getMember(String id, String psw) {
		// TODO Auto-generated method stub
		return null;
	}

}
