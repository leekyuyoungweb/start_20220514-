package inter;

import intertest.Car;

public interface CarPredicate {
	boolean test(Car car);
}
