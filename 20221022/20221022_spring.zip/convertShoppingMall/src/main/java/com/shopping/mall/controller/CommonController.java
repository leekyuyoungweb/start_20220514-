package com.shopping.mall.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CommonController {

	@RequestMapping(value = "/ajax", method = RequestMethod.GET)
	public ModelAndView testview() {
		ModelAndView mav = new ModelAndView("ajax/ajaxtest1");
//		mav.addObject("lists",lists);
		return mav; 
	}
}
