/**
 * 
 * interface
 *
 */
public class Demo1 {

	public static void main(String[] args) {		
		
		A a = new A(new C());
		a.processing();

	}

}
