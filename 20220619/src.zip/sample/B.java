package sample;


public class B extends A {
	void test() {
		super.public_value_a = 0;
		super.protected_value_a = 0;
		super.value_a = 0;
	}
}
