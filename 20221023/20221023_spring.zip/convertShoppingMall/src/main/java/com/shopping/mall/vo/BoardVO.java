package com.shopping.mall.vo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BoardVO {
	private String id;
	private String contents;
	private String boardtype;
	private String regist_day;	
}
