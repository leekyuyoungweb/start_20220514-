package model;

import repository.LoginRepository;

public class LoginService {
	private LoginRepository repository = new LoginRepository();
	/**	 
	 * 아이디와패스워드를 가지고 DB 정보를 조회해서 해당 데이터로 vo객체를 만들고 반환
	 */
	public MemberVO getMember(String id, String psw) {		
		return repository.getMember(id,psw);
	}

}
