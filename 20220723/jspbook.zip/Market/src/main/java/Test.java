import java.util.Date;

class Temp{
	int count = 0;
	public void _jspService() {
		System.out.println(++count);
	}
}

public class Test {
	
	public static void main(String[] args) {
		new Date();
		Temp t = new Temp();
		for (int i = 0; i < 10; i++) {
			t._jspService();
		}
	}

}
