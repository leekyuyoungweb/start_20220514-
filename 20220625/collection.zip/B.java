package collection;

public class B {
	public void B1() {}
	final public void B2() {}
	public void B2(int a) {}

}
