
public class Triangle {
	int width,height;
	void area() {
		System.out.printf("%.2f\n",width*height/2.0);
	}	
}
