package com.shopping.mall.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

// 결재요청 vo -> 결재요청할때 사용
class ReadyResponse {
	private String tid;
	private String next_redirect_pc_url;
	private String partner_order_id;
}

// 결재승인요청vo -> 결재승인요청할 때 담아서 보냄.
class ApproveResponse {
	private String aid;
	private String tid;
	private String cid;
	private String sid;
	private String partner_order_id;
	private String partner_user_id;
	private String payment_method_type;
	private String item_name;
	private String item_code;
	private int quantity;
	private String created_at;
	private String approved_at;
	private String payload;
	private Amount amount;

}

// 결재내역 vo -> 결재내역을 가져올 때 사용.
class Amount {
	private int total;
	private int tax_free;
	private int vat;
	private int point;
	private int discount;
}

@Controller
public class KaKaoController {
	private static final Logger log = LoggerFactory.getLogger(BoardrController.class);
	
	@RequestMapping(value = "/kakao", method = RequestMethod.GET)
	public ModelAndView kakao(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		payReady(100);
		return null;
	}
	
	@RequestMapping(value = "pay/completed")
	public ModelAndView completed(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 승인");
		return null;
	}
	@RequestMapping(value = "pay/cancel")
	public ModelAndView cancel(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 취소");
		return null;
	}
	@RequestMapping(value = "pay/fail")
	public ModelAndView fail(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 실패");
		return null;
	}
	
	
	
	// service
	public ReadyResponse payReady(int totalAmount) {

		// 카카오가 요구한 결제요청request값을 담아줍니다.
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("cid", "TC0ONETIME");
		parameters.add("partner_order_id","partner_order_id");
		parameters.add("partner_user_id", "partner_user_id");
		parameters.add("item_name", "초코파이");
		parameters.add("quantity", 1);
		parameters.add("total_amount", 2200);
		parameters.add("vat_amount", "200");
		parameters.add("tax_free_amount", "0");
		parameters.add("approval_url", "http://localhost:8080/pay/completed"); // 결제승인시 넘어갈 url
		parameters.add("cancel_url", "http://localhost:8080/pay/cancel"); // 결제취소시 넘어갈 url
		parameters.add("fail_url", "http://localhost:8080/pay/fail"); // 결제 실패시 넘어갈 url

		log.info("파트너주문아이디:" + parameters.get("partner_order_id"));
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<MultiValueMap<String,Object>>(parameters, getHeaders());
		// 외부url요청 통로 열기.
		RestTemplate template = new RestTemplate();
		String url = "https://kapi.kakao.com/v1/payment/ready";
		// template으로 값을 보내고 받아온 ReadyResponse값 readyResponse에 저장.
		ReadyResponse readyResponse = template.postForObject(url, requestEntity, ReadyResponse.class);
		log.info("결재준비 응답객체: " + readyResponse);
		// 받아온 값 return
		return readyResponse;
	}
	// 결제 승인요청 메서드
		public ApproveResponse payApprove(String tid, String pgToken) {			
			
			// request값 담기.
			MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
			parameters.add("cid", "TC0ONETIME");
			parameters.add("tid", tid);
			parameters.add("partner_order_id", "초코파이주문"); // 주문명
			parameters.add("partner_user_id", "회사명");
			parameters.add("pg_token", pgToken);
			
	        // 하나의 map안에 header와 parameter값을 담아줌.
			HttpEntity<MultiValueMap<String, String>> requestEntity 
			= new HttpEntity<MultiValueMap<String,String>>(parameters, this.getHeaders());
			
	        // 외부url 통신
			RestTemplate template = new RestTemplate();
			String url = "https://kapi.kakao.com/v1/payment/approve";
	        // 보낼 외부 url, 요청 메시지(header,parameter), 처리후 값을 받아올 클래스. 
			ApproveResponse approveResponse = template.postForObject(url, requestEntity, ApproveResponse.class);
			log.info("결재승인 응답객체: " + approveResponse);
			
			return approveResponse;
		}
		// header() 셋팅
		private HttpHeaders getHeaders() {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "KakaoAK b181663dd7ac31823e80b4b7e6f00dba");
			headers.set("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
			
			return headers;
		}
}
