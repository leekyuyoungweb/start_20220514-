package sample;

public class Teacher extends Human{	
	public void teach() {}
}
