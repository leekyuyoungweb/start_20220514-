package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.DbConn;
import model.MemberVO;

public class LoginRepository {
	private static Connection conn = null;
	public LoginRepository() {
		try {
			conn = DbConn.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	public MemberVO getMember(String id, String psw) {
		MemberVO vo = null;
		String sql = "select * from member where id = ? and passwd = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, psw);
			rs = pstmt.executeQuery();
			if (rs.next()) vo = bindMemberVo(rs);	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt !=null) pstmt.close();				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		return vo;
	}
	private MemberVO bindMemberVo(ResultSet rs) throws SQLException {
		return new MemberVO(
			rs.getString("address"),
			rs.getString("birth"),
			rs.getString("gender"),
			rs.getString("id"),
			rs.getString("mail"),
			rs.getString("name"),
			rs.getString("passwd"),
			rs.getString("phone"),
			rs.getString("regist_day")
		);
	}

}
