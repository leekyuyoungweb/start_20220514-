package model;
// DB에서 읽은 하나의 데이터
public class MemberVo {
	private String id;
	private String password;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "MemberVo [id=" + id + ", password=" + password + "]";
	}
	
}
