package model;

import repository.UpdateRepository;

public class UpdateService {
	private UpdateRepository repository = new UpdateRepository();
	public boolean updateMember(MemberVO vo) {
		return repository.updateMember(vo);		
	}

}
