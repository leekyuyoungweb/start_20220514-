package main;

import sample.A;

public class ADemo {

	public static void main(String[] args) {		
		A a = new A();
		a.public_value_a = 10;		
	}

}
