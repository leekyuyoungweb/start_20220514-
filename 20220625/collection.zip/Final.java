package collection;


public class Final {	

	public static void main(String[] args) {
		int number = 100;
		number = 200;
		number = 300;
		
		final int MAX;  // 상수
		MAX = 100;
		
		C c = new C();
		
		
	}

}
