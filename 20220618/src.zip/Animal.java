
public class Animal {
	int age;
	void show() {
		System.out.println("나는 동물이다.");
	}
}
