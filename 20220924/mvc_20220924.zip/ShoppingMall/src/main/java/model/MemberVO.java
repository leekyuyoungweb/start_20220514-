package model;

public class MemberVO {
	private String address;
	private String birth;
	private String gender;
	private String id;
	private String mail;
	private String name;
	private String passwd;
	private String phone;
	private String regist_day;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRegist_day() {
		return regist_day;
	}
	public void setRegist_day(String regist_day) {
		this.regist_day = regist_day;
	}
	public MemberVO(String address, String birth, String gender, String id, String mail, String name, String passwd,
			String phone, String regist_day) {
		super();
		this.address = address;
		this.birth = birth;
		this.gender = gender;
		this.id = id;
		this.mail = mail;
		this.name = name;
		this.passwd = passwd;
		this.phone = phone;
		this.regist_day = regist_day;
	}
	public MemberVO() {}
	
}

