package generic;

public class Boricha {

}
