package exception;

public class Person {

	public void method() {}
}
