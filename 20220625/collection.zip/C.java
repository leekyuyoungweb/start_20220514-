package collection;

public class C extends B {

	@Override
	public void B1() {
		// TODO Auto-generated method stub
		super.B1();
	}

	@Override
	public void B2(int a) {
		// TODO Auto-generated method stub
		super.B2(a);
	}

}
