package generic;

public class Bear {

}
