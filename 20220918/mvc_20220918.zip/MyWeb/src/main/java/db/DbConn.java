package db;

import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DbConn {
	private DbConn() {}
	public static Connection getConnection() throws Exception {
		
//		File f = new File("ShoppingMall/ShoppingMall/src/main/java");
//		String absFilePath =  f.getAbsolutePath();
		Properties pro = new Properties();		
		pro.load(new FileReader(new File("F:\\2.수원아카데미\\2.주말오후\\ShoppingMall\\MyWeb\\src\\main\\java\\db\\db.properties")));		
		String url = pro.getProperty("url");//"jdbc:mysql://localhost:3306/webmarketdb";
		String user = pro.getProperty("user");// "admin";
		String psw = pro.getProperty("psw");// "admin1234";
		
//		Class.forName("com.mysql.jdbc.Driver");
		Class.forName(pro.getProperty("dirivername"));
		return DriverManager.getConnection(url,user,psw);		
	}
}
