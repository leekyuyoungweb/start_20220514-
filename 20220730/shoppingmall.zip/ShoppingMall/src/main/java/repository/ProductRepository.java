package repository;

import java.util.ArrayList;
import java.util.List;

import entity.Product;
// DB 와  entity에 있는 데이터객체(즉 bean)과 데이터를 주고받는 역활
public class ProductRepository {
	private List<Product> listOfProduct = new ArrayList<Product>();
	// 차후에 DB와 연동되서 데이터 가져오는 코드로 변경예정
	public ProductRepository() {
		listOfProduct.add(new Product("p1234","아이폰","1200000","상품 사양...","애플","smartphone","100","NEW"));
		listOfProduct.add(new Product("p1235","갤럭시","1000000","상품 사양...","삼성","smartphone","300","NEW"));
		listOfProduct.add(new Product("p1236","엘지그램","2200000","상품 사양...","엘지","notebook","500","NEW"));		
	}
	// 상품전체 리스트를 반환하는 메소드
	public List<Product> getAllProducts(){
		return listOfProduct;
	}
	
}
