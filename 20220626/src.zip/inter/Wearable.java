package inter;

public interface Wearable {
	public void putOn();
	public void putOff();
}
