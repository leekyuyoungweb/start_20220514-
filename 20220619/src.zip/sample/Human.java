package sample;

public class Human {
	public void study() {};
}
