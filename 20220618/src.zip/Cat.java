
public class Cat extends Animal{

	@Override
	void show() {		
		System.out.println("나는 고양이다.");
	}
	
}
