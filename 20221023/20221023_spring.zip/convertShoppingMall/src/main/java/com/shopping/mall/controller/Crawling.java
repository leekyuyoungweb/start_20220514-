package com.shopping.mall.controller;

import org.springframework.stereotype.Controller;


@Controller
public class Crawling {

	
}
