package exception;
/**
 * RunTimeExceptioin
 * @author User
 *
 */
public class Exception3 {

	public static void main(String[] args) {
		int[] array = {0,1,2};
		System.out.println(array[3]);

	}

}
