package entity;

// ProductVO , ProductDTO, entity.Product

public class Product {
	private String productId;	// 상품아이디(pk)
	private String pname;		// 상품명
	private String price;		// 상품 가격
	private String desc;		// 상품 설명
	private String manufacturer; // 제조사
	private String category;	// 상품분류(식품,가전...)
	private String unitStock;	// 재고
	private String condition;	// 신품 or 중고
	private String filename;	// 이미지파일
	private int quantity;		// 장바구니에 담길 수량
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public Product() {}
	public Product(String productId, String pname, String price, String desc, String manufacturer, String category,
			String unitStock, String condition, String filename) {
		super();
		this.productId = productId;
		this.pname = pname;
		this.price = price;
		this.desc = desc;
		this.manufacturer = manufacturer;
		this.category = category;
		this.unitStock = unitStock;
		this.condition = condition;
		this.filename = filename;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getUnitStock() {
		return unitStock;
	}
	public void setUnitStock(String unitStock) {
		this.unitStock = unitStock;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", pname=" + pname + ", price=" + price + ", desc=" + desc
				+ ", manufacturer=" + manufacturer + ", category=" + category + ", unitStock=" + unitStock
				+ ", condition=" + condition + ", filename=" + filename + ", quantity=" + quantity + "]";
	}
	
	
	
}
