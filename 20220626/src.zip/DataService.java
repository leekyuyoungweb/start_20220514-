
public interface DataService {
	public int getData();
}
