
public class Dog extends Animal{

	@Override
	void show() {
		System.out.println("나는 강아지다");
	}
	
}
