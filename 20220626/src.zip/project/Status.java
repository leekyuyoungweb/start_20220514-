package project;

public enum Status {
	PROCESS,DONE,CANCEL,HOLD,RESUME,DROP
}
