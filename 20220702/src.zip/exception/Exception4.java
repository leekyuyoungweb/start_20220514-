package exception;
/**
 * 검사형 Exception
 * @author User
 *
 *throws InterruptedException --> 예외를 던지기(떠 넘기기)
 *
 *try {} ~ catch(){} 해당코드에서 해결하기
 */
public class Exception4 {

	public static void main(String[] args)  {
		System.out.println("시작...");		
//		Thread.sleep(1000);		
		System.out.println("끝.. 이 문장이 보이면 시작이 출력되고 1초가 지나서 보임");

	}

}
