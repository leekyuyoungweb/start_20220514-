
public class Human3Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human3 h = new Human3("둘리", 100);
		System.out.println(h);		
	}

	
	
}
