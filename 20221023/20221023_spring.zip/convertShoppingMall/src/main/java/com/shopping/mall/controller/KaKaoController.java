package com.shopping.mall.controller;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.mall.kakaovo.ApproveResponse;
import com.shopping.mall.kakaovo.KakaoPayService;
import com.shopping.mall.kakaovo.ReadyResponse;

@Controller
public class KaKaoController {
	private static final Logger log = LoggerFactory.getLogger(BoardrController.class);
	@Autowired
	KakaoPayService kakaopayService;

	@RequestMapping(value = "/kakao", method = RequestMethod.GET)
	public ModelAndView kakao(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		ModelAndView mav = new ModelAndView("kakao/kakao");
		return mav;

	}

	// 카카오페이결제 요청
	@GetMapping("/order/pay")
	public @ResponseBody ReadyResponse payReady(@RequestParam(name = "total_amount") int totalAmount, Model model) {

		// 카카오 결제 준비하기 - 결제요청 service 실행.
		ReadyResponse readyResponse = kakaopayService.payReady(totalAmount);

		return readyResponse; // 클라이언트에 보냄.(tid,next_redirect_pc_url이 담겨있음.)
	}

	// 결제승인요청
	@GetMapping("/order/pay/completed")
	public String payCompleted(@RequestParam("pg_token") String pgToken, 
//			@ModelAttribute("tid") String tid,
//			@ModelAttribute("order") Order order, 
			Model model) {

		log.info("결제승인 요청을 인증하는 토큰: " + pgToken);
//		log.info("주문정보: " + order);
//		log.info("결재고유 번호: " + tid);

		// 카카오 결재 요청하기
//		ApproveResponse approveResponse = kakaopayService.payApprove(tid, pgToken);

		// 5. payment 저장
		// orderNo, payMathod, 주문명.
		// - 카카오 페이로 넘겨받은 결재정보값을 저장.		

		return "redirect:/pay/completed";
	}

	@RequestMapping(value = "pay/completed")
	public ModelAndView completed(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 승인");		
		ModelAndView mav = new ModelAndView("kakao/completed");
		return mav;
	}

	@RequestMapping(value = "order/pay/cancel")
	public ModelAndView cancel(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 취소");
		ModelAndView mav = new ModelAndView("kakao/cancel");
		return mav;
	}

	@RequestMapping(value = "order/pay/fail")
	public ModelAndView fail(@RequestParam(defaultValue = "1") String num, Locale locale, Model model) {
		System.out.println("결제 실패");
		return null;
	}

}
