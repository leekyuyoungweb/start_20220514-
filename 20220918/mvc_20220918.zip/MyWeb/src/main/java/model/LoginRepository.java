package model;
/**
 * 
 * DB 접속정보를 이용해서 접속
 * DB를 조회해서 결과를 리턴
 *
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.DbConn;

public class LoginRepository {
	private Connection conn = null;
	public LoginRepository() {
		try {
			conn = DbConn.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public MemberVo getMemberVoById(String id) {
		MemberVo vo = new MemberVo();
		String sql = "select * from member where id = ?";		
		try {
			PreparedStatement pstmt =  conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs =  pstmt.executeQuery();
			rs.next();
			vo.setId(rs.getString("id"));
			vo.setPassword(rs.getString("passwd"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}
}
