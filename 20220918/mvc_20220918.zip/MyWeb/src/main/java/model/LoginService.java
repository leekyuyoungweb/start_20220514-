package model;
/**
 * 
 * @author C-Main
 * 모델
 * 로그인 성공여부를 확인 from DB로 부터
 * -- DB와 통신해서 데이터를 가져오는 모듈을 호출해서 
 * -- 로그인 여부를 리턴
 */
public class LoginService {
	private LoginRepository repository = new LoginRepository();	
	public boolean isLogin(String id, String password) {
		MemberVo vo =  repository.getMemberVoById(id);
		return id.equals(vo.getId()) && password.equals(vo.getPassword());
	}
}
