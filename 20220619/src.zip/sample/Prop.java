package sample;

public class Prop extends Researcher{
	public void teach() {}
}
