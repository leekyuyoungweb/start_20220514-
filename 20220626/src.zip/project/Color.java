package project;

public enum Color {
	BLACK,RED,GREEN,BLUE,YELLOW
}
