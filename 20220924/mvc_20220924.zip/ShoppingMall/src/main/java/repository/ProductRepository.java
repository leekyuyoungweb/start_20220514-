package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.DbConn;
import entity.Product;
// DB 와  entity에 있는 데이터객체(즉 bean)과 데이터를 주고받는 역활
public class ProductRepository {
	private List<Product> listOfProduct = new ArrayList<Product>();
	// 차후에 DB와 연동되서 데이터 가져오는 코드로 변경예정
	
	private static ProductRepository instance = null;
	private static Connection conn = null;
	private ProductRepository() throws Exception {
		conn= DbConn.getConnection();
	}	
	public static ProductRepository getInstance() {
		if(instance == null)
			try {
				instance =  new ProductRepository();
			} catch (Exception e) {
				e.printStackTrace();
			}
		return instance;
	}
	
	// 상품전체 리스트를 반환하는 메소드
	public List<Product> getAllProducts(){
		Statement stmt = null;
		String sql = null;
		ResultSet rs =  null;
		try {
			stmt =  conn.createStatement();
			sql = "select * from product";
			rs =  stmt.executeQuery(sql);
			while(rs.next()) {
				Product p = makeProduct(rs);				
				listOfProduct.add(p);				
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
			}catch (Exception e) {}
		}
		
		
		return listOfProduct;
	}
	// rs 객체를 받아서 product 객체를 리턴하는 함수
	private Product makeProduct(ResultSet rs) throws SQLException {
		Product p = new Product();
		p.setProductId(rs.getString("productId"));
		p.setPname(rs.getString("pname"));
		p.setPrice(rs.getString("price"));//				
		p.setDesc(rs.getString("pdesc"));
		p.setManufacturer(rs.getString("manufacturer"));
		p.setCategory(rs.getString("category"));
		p.setUnitStock(rs.getString("unitStock"));
		p.setCondition(rs.getString("pcondition"));
		p.setFilename(rs.getString("filename"));
		return p;
	}
	
	// 상품 productid를 가지고 해당 상품을 찾는 메소드
	// DB 에 접속해서 데이터를 
	public Product getProductById(String productID) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql =  "select * from product where productId = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, productID);
			rs = pstmt.executeQuery();
			if(!rs.next())
				return null;
			return makeProduct(rs);			
		}catch (Exception e) {return null;}
		finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			}catch (Exception e) {}
		}
		
	}
	
	//신규상품 등록
	// 전달받은 product객체의 productid를 가지고 조회를해서 데이터가 있으면 
	// 신규등록 불가
	// 그렇지 않으면 추가
	// insert 쿼리
	//
	public void addProduct(Product product) {
		String id = product.getProductId();
		if (getProductById(id) != null)
			return;				
		
		String sql = "insert into productId values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = null;		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getProductId());
			pstmt.setString(2, product.getPname());
			pstmt.setString(3, product.getPrice());
			pstmt.setString(4, product.getDesc());
			pstmt.setString(5, product.getManufacturer());
			pstmt.setString(6, product.getCategory());
			pstmt.setString(7, product.getUnitStock());
			pstmt.setString(8, product.getCondition());
			pstmt.setString(9, product.getFilename());
			pstmt.executeUpdate();
		}catch (Exception e) {}
		finally {
			try {				
				if(pstmt != null) pstmt.close();
			}catch (Exception e) {}
		}
	}
}
