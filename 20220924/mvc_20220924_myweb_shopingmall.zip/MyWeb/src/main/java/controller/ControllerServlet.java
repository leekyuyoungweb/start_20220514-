package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.LoginService;

public class ControllerServlet extends HttpServlet {
	private LoginService service = new LoginService();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("서블릿 호출 get 방식...........");
		req.setAttribute("message", "hello servlet");
		// 적합한 view를 선택
		RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
		rd.forward(req, resp);		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html; charset = utf-8");
		// 화면에서 전달받은 데이터
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		// 적합한 비지니스 모듈 호출
		// 비지니스 모듈 - 로그인 여부
		boolean isLogin =  service.isLogin(id, password);
		RequestDispatcher rd = null;
		if (isLogin)
			rd = req.getRequestDispatcher("success.jsp");
		else 
			rd = req.getRequestDispatcher("faile.jsp");	
		rd.forward(req, resp);
	}

}
